package testcases;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.QuickEntryPage;

import pages.LoginPage;
import wrappers.PortalWrappers;

public class ZSOAorder extends PortalWrappers {

	@BeforeClass
	public void setValues() {
		browserName = "chrome";
		testCaseName = "ZSOA order";
		testDescription = "Create ZSOA order";
		category="smoke";
		authors="Manoj";
		dataSheetName ="Login details";
//		dataSheetName ="Article details";
//		dataSheetName ="PO details";
	}

	@Test(priority = 0, dataProvider="fetchData")
	public void ZSOA(String userName, String password, String storeNum) throws InterruptedException{

		new LoginPage(driver,test)
		.EnterUserID(userName)
		.EnterPassword(password)
		.ClickLogin()
		.selectStore()
		.selectStoreName()
		.enterStoreNum(storeNum)
		.clickOk()
		.selectQuickEntry();
	}
	@Test(priority = 1, dataProvider="getArticles")
	public void testTwoZSOA(String rowno, String store, String article, String qty) throws IOException
	{
			new QuickEntryPage(driver,test)
				
			.enterArticles(rowno, store, article, qty);
	}
	@Test(priority = 2, dataProvider="getPO")
	public void testThreeZSOA(String potext, String deliverydate) throws IOException, EncryptedDocumentException, InvalidFormatException
	{
		new QuickEntryPage(driver,test)
			.addtoCart()
			.clickCart()
			.selectLine()
			.clickCheckOut()
			.selectSpecial()
			.clickSubmit()
			.enterRetPO(potext)
			.clickShipRet()
			.clickSpecialCnt();
//			.enterPO(potext)
//			.enterDlvDate(deliverydate)
//			.confirmCheckout()
//			.hitOk()
//			.gotoOrderStatus()
//			.getOrderdetails();	
	}
	
}











