package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.PortalWrappers;

public class LoginPage extends PortalWrappers{
	
	
	public LoginPage(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver; 
		this.test = test;
		if(!verifyTitle("qaejdportal.com"))
			reportStep("This is not Login Page", "FAIL");
	}
		
		public LoginPage EnterUserID(String userID)
		{
			enterByName("username", userID);
			return this;
		}
		public LoginPage EnterPassword(String passWord)
		{
			enterByName("password", passWord);
			return this;
		}
		public HomePage ClickLogin()
		{
			clickByClassName("credentials_input_submit");
			return new HomePage(driver,test);
		}
	}
