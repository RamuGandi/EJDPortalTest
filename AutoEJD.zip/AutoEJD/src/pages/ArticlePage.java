package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.PortalWrappers;

public class ArticlePage extends PortalWrappers{
	
	public ArticlePage(RemoteWebDriver driver, ExtentTest test)
	{
		this.driver=driver;
		this.test = test;
		if(!verifyTitle("EJD Portal"))
			reportStep("This is not Home Page", "FAIL");
	}
	public ArticlePage clickQtyField()
	{
		clickByClassName("contentMainPlaceHolder_resultListView_tbxQty_0");
		return this;
	}
	public ArticlePage enterQty(String qty)
	{
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		enterByName("contentMainPlaceHolder_resultListView_tbxQty_0", qty);
		return this;
	}
	
}
