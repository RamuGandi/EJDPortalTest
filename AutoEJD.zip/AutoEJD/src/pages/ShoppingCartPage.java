package pages;

import org.openqa.selenium.remote.RemoteWebDriver;


import com.relevantcodes.extentreports.ExtentTest;

import wrappers.PortalWrappers;

public class ShoppingCartPage extends PortalWrappers {
	
	public ShoppingCartPage(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver; 
		this.test = test;
		if(!verifyTitle("qaejdportal.com"))
			reportStep("This is not Login Page", "FAIL");
	}
	public ShoppingCartPage selectLine()
	{
		clickById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl05_CHKCARTSelectCheckBox");
		return this;
	}
	public ShoppingCartPage clickCheckOut()
	{
		clickById("btnCheckOut");
		return this;
	}
	public ShoppingCartPage selectSpecial()
	{
		clickByXpath(".//*[@id='rdSpecial']");
		return this;
	}
	
	public ShoppingCartPage clickSubmit()
	{
		clickByXpath(".//*[@id='divConfirmCheckout']/div[2]/input");
		return this;
	}
	public ShoppingCartPage enterPO(String poText)
	{
		enterById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl04_TXT_PO Number", poText);
		return this;
	}
	public ShoppingCartPage enterRetPO(String poText)
	{
		enterById("txtPONumber", poText);
		return this;
	}
	public ShoppingCartPage clickShipRet()
	{
		clickById("rdImmediateStore");
		return this;
	}
	public ShoppingCartPage clickShipcust()
	{
		clickById("rdDiffAddress");
		return this;
	}
	
	
	public ShoppingCartPage clickSpecialCnt()
	{
		clickById("btnSpcOrderCont");
		return this;
	}
	
	public ShoppingCartPage enterDlvDate(String dlvdate)
	{
		enterById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl04_TXT_EXPECTEDSHIPDATE", dlvdate);
		return this;
	}
	public ShoppingCartPage confirmCheckout()
	{
		clickByXpath(".//*[@id='btnConfirm']");
		return this;
	}
	public ShoppingCartPage hitOk()
	{
		clickByXpath(".//*[@class='PopupOuter ui-draggable']/div[2]/input[1]");
		driver.switchTo().defaultContent();
		return this;
	}
	public OrderStatusPage gotoOrderStatus()
	{
		mouseOverByXpath(".//*[@class='minimenu2']/span[1]");
		clickByXpath(".//*[@class='minimenu2']/ul[1]/li[3]");
		driver.switchTo().frame("iframeAppHost");
		return new OrderStatusPage(driver,test);
	}
}
