package com.portal.library;

import java.io.File;
import java.io.FileInputStream;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDataConfig {

	XSSFWorkbook wb1;
	XSSFSheet sh1;
	
	public ExcelDataConfig(String excelpath)
	{
		try {
			File src=new File(excelpath);
			FileInputStream fis= new FileInputStream(src);
			wb1= new XSSFWorkbook(fis);
			} 
		catch (Exception e) {
		System.out.println(e.getMessage());
		}
	}
public String getData(int sheetnum, int row, int column)
{
	sh1= wb1.getSheetAt(sheetnum);
	String data = sh1.getRow(row).getCell(column).getStringCellValue();
	return data;
}

public int getRowCount(int SheetIndex)
{
	int row = wb1.getSheetAt(SheetIndex).getLastRowNum();
	row = row+1;
	return row;
	
}
public int getColCount(int SheetIndx)
{
	sh1= wb1.getSheetAt(SheetIndx);
	int col = sh1.getRow(0).getLastCellNum();
	return col;
}
}
