/**
 * 
 */
package com.portal.library;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

/**
 * @author 500266
 *This class will call all property values from configuration file
 */
public class ConfigReader {
	
	Properties pro;
		
	public ConfigReader()
	{
		try {
			File src= new File("./ConfigurationFile/Configuratio.property");
			FileInputStream fis = new FileInputStream(src);
			pro = new Properties();
			pro.load(fis);
		} catch (Exception e) {
			System.out.println("Exception is -- "+e.getMessage());
		}
	}
	
	public String getChromePath()
	{
		String ChromePath = pro.getProperty("ChromeDriver");
		return ChromePath;
	}
	public String getUrl()
	{
		String url = pro.getProperty("URL");
		return url;
	}
	public String getIEpath()
	{
		String IEpath = pro.getProperty("IEDriver");
		return IEpath;
	}
	public String getexcelPath()
	{
		String ExclPath = pro.getProperty("ExcelPath");
		return ExclPath;
	}
	public String getexcelPathPortal()
	{
		String ExclPathPortal = pro.getProperty("ExcelPathPortal");
		return ExclPathPortal;
	}
	public String getFirefoxPath()
	{
		String geckopath = pro.getProperty("FirefoxDriver");
		return geckopath;
	}
	public String getBrowser()
	{
		String getbrowser = pro.getProperty("Browser");
		return getbrowser;
	}
}
