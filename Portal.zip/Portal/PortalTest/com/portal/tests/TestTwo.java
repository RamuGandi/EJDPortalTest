package com.portal.tests;

import java.io.IOException;

import org.testng.annotations.Test;

import com.portal.pages.QuickEntryPage;
import com.portal.wrappers.GenericWrappers;

public class TestTwo extends GenericWrappers{
	
	@Test(dataProvider="getTestData")
	public void testTwo(String rowno, String store, String article, String qty) throws IOException
	{
		new QuickEntryPage(driver)
			
		.enterArticles(rowno, store, article, qty);
		
	}

}
