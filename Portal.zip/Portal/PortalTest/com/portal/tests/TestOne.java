package com.portal.tests;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.portal.pages.LoginPage;
import com.portal.pages.QuickEntryPage;
import com.portal.wrappers.GenericWrappers;

public class TestOne extends GenericWrappers{

	@Parameters({"browser", "url", "userID", "passworD", "storeNum"})
	@Test(priority = 0)
	public void testOne(String browser, String url, String userID, String passworD, String storeNum) throws IOException{
		
		invokeApp(browser,url);
		
		new LoginPage(driver)
		
		.EnterUserID(userID)
		.EnterPassword(passworD)
		.ClickLogin()
		.selectStore()
		.selectStoreName()
		.enterStoreNum(storeNum)
		.clickOk()
		.selectQuickEntry();
	}	
	@Test(priority = 1, dataProvider="getTestData")
	public void testTwo(String rowno, String store, String article, String qty) throws IOException
	{
			new QuickEntryPage(driver)
				
			.enterArticles(rowno, store, article, qty);
			
	}
	@Parameters({"potext", "deliverydate"})
	@Test(priority = 2)
	public void testThree(String potext, String deliverydate) throws IOException, EncryptedDocumentException, InvalidFormatException
	{
		new QuickEntryPage(driver)
			.addtoCart()
			.clickCart()
			.selectLine()
			.clickCheckOut()
			.clickSubmit()
			.enterPO(potext)
			.enterDlvDate(deliverydate)
			.confirmCheckout()
			.hitOk()
			.gotoOrderStatus()
			.getOrderdetails();	
	}
	
		
}
