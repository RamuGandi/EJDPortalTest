package com.portal.wrappers;

public interface Wrappers {

	public void enterByName(String name,String text);
	public void enterByID(String ID, String text);
	public void enterByClass(String Class, String text);
	public void clickByClass(String className);
	public void clickByName(String name);
	public void clickById(String ID);
	public void verifyByID(String ID);
	public void verifyByName(String name);
	public void invokeApp(String browser, String url);
	public void invokeAppnew();
	public void clickByXpath(String xpathvalue);
	public void clickByLinktext(String linktext);
	public void selectIndexByValue(String ID, String value);
	public void verifyfieldValue(String ID, int Value);
	public void movemouseto(String xpathval);
	public void closeBrower();
}
