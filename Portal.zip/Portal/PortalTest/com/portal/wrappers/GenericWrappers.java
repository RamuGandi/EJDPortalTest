package com.portal.wrappers;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;

import com.portal.library.ConfigReader;
import com.portal.library.ExcelDataConfig;


public class GenericWrappers implements Wrappers{

public RemoteWebDriver driver;
	
	@Override
	public void enterByName(String name, String text)
	{
		try {
			driver.findElementByName(name).sendKeys(text);
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
	}
	@Override
	public void enterByID(String ID, String storeNum)
	{
		try {
			driver.findElementById(ID).sendKeys(storeNum);
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
	}
	@Override
	public void verifyByID(String ID)
	{
		boolean usernameboxPresence=driver.findElement(By.id(ID)).isDisplayed(); 
        System.out.println("Element Presence is "+usernameboxPresence);
	}
	@Override
	public void verifyByName(String name)
	{
		
		if(driver.getPageSource().contains(name))
		  {
		    System.out.println("Username is Verified");
		  }
		else
		  {
		    System.out.println("Fail");
		  }	
	}
	@Override
	public void clickByName(String name)
	{
		try {
			driver.findElementByName(name).click();
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
	}
	@Override
	public void clickById(String ID)
	{
		try {
			driver.findElementById(ID).click();
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
	}
	public void clickByLinktext(String linktext)
	{
		try {
			driver.findElementByLinkText(linktext).click();
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
	}
	@Override
	public void invokeApp(String browser, String url)
	{
		ConfigReader config = new ConfigReader();
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", config.getChromePath());
			driver=new ChromeDriver();
		}
		if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", config.getFirefoxPath());
			driver = new FirefoxDriver();
		}
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		String originalWindow = driver.getWindowHandle();
		System.out.println("Original Window handle is " + originalWindow);
	}
	public void takesnap()
	{
		
		try {
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String timeStamp = new SimpleDateFormat("MMdd_mmsss").format(Calendar.getInstance().getTime());
		FileUtils.copyFile(source, new File("./Screenshots/"+"Snap"+timeStamp+".png"));
		System.out.println("Screenshot taken");
		} catch (Exception e) {	
		System.out.println("Exception while taking Screenshot"+e.getMessage());
		}			
	}
	@Override
	public void clickByXpath(String xpathvalue)
	{
		try {
			driver.findElementByXPath(xpathvalue).click();
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
	}
	@Override
	public void selectIndexByValue(String ID, String Value)
	{
		try {
			WebElement web = driver.findElementById(ID);
			Select sl = new Select(web);
			sl.selectByValue(Value);
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());	
		}		
	}
	@Override
	public void verifyfieldValue(String ID, int Value)
	{
		String qty= driver.findElementById(ID).getAttribute("value");
		int qtynumber = Integer.parseInt(qty);
		if(qtynumber == Value){
			System.out.println("Qty displayed correctly");
			}
		else{
			System.out.println("Qty displayed Incorrectly");
			}
	}
	@DataProvider(name="getData")
	public Object[][] getdata()
	{
		ConfigReader config = new ConfigReader();
		ExcelDataConfig exconfig = new ExcelDataConfig(config.getexcelPath());
		int rows = exconfig.getRowCount(0);
		int cols = exconfig.getColCount(0);
		Object[][] data= new Object[rows][cols];
		
		for (int i=0; i<rows; i++)
		{
			for (int j=0; j<cols; j++)
			{
			data[i][j] = exconfig.getData(0, i, j);
			}
		}		
		return data;
	}
	@DataProvider(name="setData")
	public Object[][] setdata()
	{
		WebElement mytable = driver.findElement(By.xpath(".//*[@id='ctl00_MainContent_radGridOrderStatus_ctl00']"));
		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
		List<WebElement> Columns_row = rows_table.get(1).findElements(By.tagName("td")); 
		int rows_count=rows_table.size();
		int columns_count = Columns_row.size();
		Object[][] data = new Object[rows_count][columns_count];
		
		for (int j=0; j<columns_count; j++)
		{
			data[1][j] = Columns_row.get(j).getText();
		}
		return data;
	}
			
	@DataProvider(name="getDataPortal")
	public Object[][] getdataportal()
	{
		ConfigReader config = new ConfigReader();
		ExcelDataConfig exconfig = new ExcelDataConfig(config.getexcelPathPortal());
		int rows = exconfig.getRowCount(0);
		int cols = exconfig.getColCount(0);
		Object[][] data= new Object[rows][cols];
		
		for (int i=0; i<rows; i++)
		{
			for (int j=0; j<cols; j++)
			{
			data[i][j] = exconfig.getData(0, i, j);
			}
		}		
		return data;
	}
	@DataProvider(name="getTestData")
	public Object[][] getTestData()
	{
		ConfigReader config = new ConfigReader();
		ExcelDataConfig exconfig = new ExcelDataConfig(config.getexcelPathPortal());
		int rows = exconfig.getRowCount(0);
		int cols = exconfig.getColCount(0);
		Object[][] data= new Object[rows][cols];
		
		for (int i=0; i<rows; i++)
		{
			for (int j=0; j<cols; j++)
			{
			data[i][j] = exconfig.getData(0, i, j);
			}
		}		
		return data;
	}
	public void datepicker(String date)
	{
		String dt = date;
		String spltr[] = dt.split("-");
		String day = spltr[0];
		String monthYear = spltr[1];
		selectdate(monthYear, day);
				
	}
	
	public void selectdate(String monthYear, String day) {
		
		WebElement table = driver.findElementByXPath("(//table[@class='rb-monthTable first last'])[2]//tr/td[@class='monthTitle']");
		
		if(table.getText().equals(monthYear)){
			
			List<WebElement> dates = driver.findElementsByXPath("(//table[@class='rb-monthTable first last'])[2]//tr/td");
			for (WebElement d : dates){
				if(d.getText().equals(day)){
					d.click();
				}
			}
		}
		driver.findElementByXPath("(//table[@class='rb-monthTable first last'])[2]//tr/td[@class='next']").click();
		selectdate(monthYear, day);
	}
	public void closeBrower()
	{
		driver.close();
	}
	@Override
	public void movemouseto(String xpathval) {
		// TODO Auto-generated method stub
		WebElement element = driver.findElement(By.xpath(xpathval));
		Actions action = new Actions(driver);
        action.moveToElement(element).build().perform();
	}
	@Override
	public void invokeAppnew() {
		// TODO Auto-generated method stub
		ConfigReader config = new ConfigReader();
		String browser = config.getBrowser();
		String url = config.getUrl();
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", config.getChromePath());
			driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", config.getFirefoxPath());
			driver = new FirefoxDriver();
		}
		else
		{
			System.setProperty("webdriver.ie.driver", config.getIEpath());
			driver = new InternetExplorerDriver();
		}
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		String originalWindow = driver.getWindowHandle();
		System.out.println("Original Window handle is " + originalWindow);
	}
	@Override
	public void enterByClass(String Class, String text) {
		try {
			driver.findElementByClassName(Class).sendKeys(text);
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
		
	}
	@Override
	public void clickByClass(String className) {
		try {
			driver.findElementByClassName(className).click();
		} catch (Exception e) {
			System.out.println("Exception message is "+e.getMessage());
		}
		
	}
}