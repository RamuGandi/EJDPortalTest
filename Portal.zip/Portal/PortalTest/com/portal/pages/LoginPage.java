package com.portal.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.portal.wrappers.GenericWrappers;

public class LoginPage extends GenericWrappers{
	
	
	public LoginPage (RemoteWebDriver driver)
		{
			this.driver=driver;
		}
		
		public LoginPage EnterUserID(String userID)
		{
			enterByClass("credentials_input_text", userID);
			return this;
		}
		public LoginPage EnterPassword(String passWord)
		{
			enterByClass("credentials_input_password", passWord);
			return this;
		}
		public HomePage ClickLogin()
		{
			clickByClass("credentials_input_submit");
			return new HomePage(driver);
		}
	}
