package com.portal.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.portal.wrappers.GenericWrappers;

public class HomePage extends GenericWrappers{

	public HomePage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	public HomePage selectStore()
	{
		clickById("awhStoreSelPopup_ddlSearchColumn");
		return this;
	}
	public HomePage selectStoreName()
	{
		selectIndexByValue("awhStoreSelPopup_ddlSearchColumn", "StoreNo");
		return this;
	}
	public HomePage enterStoreNum(String storeNum)
	{
		enterByID("awhStoreSelPopup_tbxSearchGrid", storeNum);
		return this;
	}
	public HomePage clickOk()
	{
		clickByClass("gridHourGlass");
		return this;
	}
	public HomePage clickonsearch()
	{
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		clickByXpath(".//*[@id='header_ProductSearchBox_solrSearchBox']");
		return this;
	}
	public HomePage enterArticle(String article)
	{
		String c=".//*[@id='header_ProductSearchBox_solrSearchBox']";
		List<WebElement> quickEntry = driver.findElementsByXPath(c);
		int siz=quickEntry.size();
		System.out.println(siz);
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(c)));
		web.sendKeys(article);;
		//enterByID("header_ProductSearchBox_solrSearchBox", article);
		return this;
	}
	public ArticlePage clickSearch()
	{
		String b=".//*[@id='header_ProductSearchBox_hourglass']";
		List<WebElement> quickEntry = driver.findElementsByXPath(b);
		int siz=quickEntry.size();
		System.out.println(siz);
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(b)));
		web.click();
		//clickByXpath(".//*[@id='header_ProductSearchBox_hourglass']");
		return new ArticlePage(driver);
	}
	public QuickEntryPage selectQuickEntry()
	{
		String a="//a[contains(text(),'Quick Entry') and @class='btnHomeLightBlue']";
		List<WebElement> quickEntry = driver.findElementsByXPath(a);
		int siz=quickEntry.size();
		System.out.println(siz);
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a)));
		web.click();
		driver.manage().timeouts().implicitlyWait(8000, TimeUnit.MILLISECONDS);
		driver.switchTo().frame("iframeAppHost");
		//((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)", "");
		//driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		//clickByXpath(a);
		return new QuickEntryPage(driver);
		
	}
}
