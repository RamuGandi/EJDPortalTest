package com.portal.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.portal.wrappers.GenericWrappers;

public class ShoppingCartPage extends GenericWrappers {
	
	public ShoppingCartPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	public ShoppingCartPage selectLine()
	{
		clickById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl05_CHKCARTSelectCheckBox");
		return this;
	}
	public ShoppingCartPage clickCheckOut()
	{
		clickById("btnCheckOut");
		return this;
	}
	public ShoppingCartPage clickSubmit()
	{
		clickByXpath(".//*[@id='divConfirmCheckout']/div[2]/input");
		return this;
	}
	public ShoppingCartPage enterPO(String poText)
	{
		enterByID("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl04_TXT_PO Number", poText);
		return this;
	}
	public ShoppingCartPage enterDlvDate(String dlvdate)
	{
		enterByID("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl04_TXT_EXPECTEDSHIPDATE", dlvdate);
		return this;
	}
	public ShoppingCartPage confirmCheckout()
	{
		clickByXpath(".//*[@id='btnConfirm']");
		return this;
	}
	public ShoppingCartPage hitOk()
	{
		clickByXpath(".//*[@class='PopupOuter ui-draggable']/div[2]/input[1]");
		driver.switchTo().defaultContent();
		return this;
	}
	public OrderStatusPage gotoOrderStatus()
	{
		movemouseto(".//*[@class='minimenu2']/span[1]");
		clickByXpath(".//*[@class='minimenu2']/ul[1]/li[3]");
		driver.switchTo().frame("iframeAppHost");
		return new OrderStatusPage(driver);
	}
}
