package com.portal.pages;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.portal.wrappers.GenericWrappers;

public class OrderStatusPage extends GenericWrappers {

	public OrderStatusPage(RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	public OrderStatusPage getallOrderdetails()
	{
		WebElement mytable = driver.findElement(By.xpath(".//*[@id='ctl00_MainContent_radGridOrderStatus_ctl00']"));
		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
		int rows_count = rows_table.size();
		for (int row=0; row<rows_count; row++){ 
		List<WebElement> Columns_row = rows_table.get(row+1).findElements(By.tagName("td")); 
		int columns_count = Columns_row.size();
		System.out.println("Number of cells In Row "+row+" are "+columns_count);
		for (int column=0; column<columns_count; column++){ 
		String celtext = Columns_row.get(column).getText();
		System.out.println("Cell Value of row number "+row+1+" and column number "+column+" Is "+celtext);
		}
		System.out.println("-------------------------------------------------- ");
		}
	return this;
	}
	public OrderStatusPage getOrderdetails() throws IOException, EncryptedDocumentException, InvalidFormatException
	{
		WebElement mytable = driver.findElement(By.xpath(".//*[@id='ctl00_MainContent_radGridOrderStatus_ctl00']"));
		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
		List<WebElement> Columns_row = rows_table.get(1).findElements(By.tagName("td")); 
		//int rows_count=rows_table.size();
		int columns_count = Columns_row.size();
		FileOutputStream fos= new FileOutputStream(new File("D:\\500266\\ExcelData\\OrderData.xls"));
		Workbook wkb = new HSSFWorkbook();
		Sheet sheet1= wkb.createSheet("Data");
		Row excelRow = sheet1.createRow(0);
		//String[][] celtext= new String[rows_count][columns_count];
		for (int column=0; column<columns_count; column++){ 
		String celtext = Columns_row.get(column).getText();
		System.out.println("Cell Value of row number 1 and column number "+column+" Is "+celtext);
		Cell excelCell = excelRow.createCell(column);              
				excelCell.setCellValue(celtext); 
				System.out.println(celtext);
		//fos.flush();   	
		}
		wkb.write(fos);     
		fos.close();
		wkb.close();
		return this;
	}
}

