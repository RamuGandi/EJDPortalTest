package com.portal.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.portal.wrappers.GenericWrappers;

public class ArticlePage extends GenericWrappers{
	
	public ArticlePage(RemoteWebDriver driver)
	{
		this.driver=driver;
	}
	public ArticlePage clickQtyField()
	{
		clickByClass("contentMainPlaceHolder_resultListView_tbxQty_0");
		return this;
	}
	public ArticlePage enterQty(String qty)
	{
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		enterByClass("contentMainPlaceHolder_resultListView_tbxQty_0", qty);
		return this;
	}
	
}
