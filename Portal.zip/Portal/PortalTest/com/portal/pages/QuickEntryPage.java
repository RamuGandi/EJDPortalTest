package com.portal.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.portal.wrappers.GenericWrappers;

public class QuickEntryPage extends GenericWrappers{

	public QuickEntryPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	public QuickEntryPage enterOneArticle()
	{
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		driver.findElementByXPath(".//table[@class='GridInnertables']/tbody[1]/tr[2]/td[1]/div[1]").sendKeys("24944");
		return this;
	}
	public QuickEntryPage enterArticles(String rowno, String store, String article, String qty) throws IOException
	{
			int row = Integer.parseInt(rowno);
			driver.findElementByXPath(".//*[@id='divStore_"+row+"']").sendKeys(store);
			driver.findElementByXPath(".//*[@id='divSku_"+row+"']").sendKeys(article);
			driver.findElementByXPath(".//*[@id='divQty_"+row+"']").sendKeys(qty);
		return this;
	}
	public QuickEntryPage addtoCart()
	{
		clickById("btnAddToCart");
		driver.switchTo().defaultContent();
		return this;
	}
	public ShoppingCartPage clickCart()
	{
		String a=".//span[contains(text(),'Cart')]";
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a)));
		web.click();
		//clickByXpath(".//span[contains(text(),'Cart')]");		
		//driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		driver.switchTo().frame("iframeAppHost");
		return new ShoppingCartPage(driver);
	}
}
