package wrappers;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import utils.DataInputProvider;

public class PortalWrappers extends GenericWrappers {
	
	public String browserName="chrome";
//	public String dataSheetName;
	
	
	

	@BeforeSuite
	public void beforeSuite(){
		startResult();
	}

	@BeforeTest
	public void beforeTest(){
		loadObjects();
		
//		invokeApp(browserName);
	}
	
	@BeforeMethod
	public void beforeMethod(){
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		
	}
		
	@AfterSuite
	public void afterSuite(){
		endResult();
	}

	@AfterTest
	public void afterTest(){
		unloadObjects();
		//quitBrowser();
	}
	
	//@AfterTest
	public void afterMethod(){
//		endTestcase();
	}
	
	@DataProvider(name="fetchData")
	public Object[][] getData(){
		return DataInputProvider.getSheet("Login details");		
	}	
	
	@DataProvider(name="getArticles")
	public Object[][] getData1(){
		return DataInputProvider.getSheet("Article details");		
	}	
	
	@DataProvider(name="getPOZREP")
	public Object[][] getData2(){
		return DataInputProvider.getSheet("PO details_ZREP");
	}
	
	@DataProvider(name="getPOZSOA")
	public Object[][] getData3(){
		return DataInputProvider.getSheet("PO details_ZSOA");
	}
	@DataProvider(name="getArticlesZBUL")
	public Object[][] getData4(){
		return DataInputProvider.getSheet("Article details_ZBUL");		
	}
	@DataProvider(name="getPOZBUL")
	public Object[][] getData5(){
		return DataInputProvider.getSheet("PO details_ZBUL");
	}
}






