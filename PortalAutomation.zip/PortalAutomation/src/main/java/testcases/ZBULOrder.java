package testcases;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.QuickEntryPage;
import wrappers.PortalWrappers;

public class ZBULOrder extends PortalWrappers{
	@BeforeSuite
	public void snapdirectoryDelete(){
		testCaseName = "ZBUL order";
		try {
			FileUtils.deleteDirectory(new File("E:/work/New folder/PortalAutomation/reports/images/"+testCaseName+"/"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	@BeforeTest
	public void setValues() {
		browserName = "chrome";
		testCaseName = "ZBUL order";
		testDescription = "Create ZBUL order in Portal";
		category="smoke";
		authors="Ram";
//		try {
//			FileUtils.deleteDirectory(new File("E:/work/New folder/PortalAutomation/reports/"+testCaseName+"/"));
//		} catch (IOException e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
	}
	@Test(priority = 0, dataProvider="fetchData")
	public void LogintoPortal(String userID, String passworD, String storeNum) throws IOException{

		invokeApp(browserName,testCaseName );

		new LoginPage(driver, test, testCaseName)

		.EnterUserID(userID, testCaseName)
		.EnterPassword(passworD,testCaseName)
		.ClickLogin(testCaseName)
		.selectStore(testCaseName)
		.selectStoreName(testCaseName)
		.enterStoreNum(storeNum, testCaseName)
		.clickOk(testCaseName)
		.selectEventQuckEntry(testCaseName);
	}	
	@Test(priority = 1, dataProvider="getArticlesZBUL")
	public void AddArticles(String rowno, String store, String article, String qty) throws IOException
	{
		new QuickEntryPage(driver, test, testCaseName)

		.enterBulletinArticles(rowno, store, article, qty, testCaseName);

	}

	@Test(priority = 2, dataProvider="getPOZBUL")
	public void CheckOut(String potext, String deliverydate) throws IOException, EncryptedDocumentException, InvalidFormatException, InterruptedException
	{
		new QuickEntryPage(driver,test, testCaseName)
			.addtoCart(testCaseName)
			.clickCart()
			.selectEventPlanner(testCaseName)
			.selectEventLine(testCaseName)
			.clickCheckOut(testCaseName)
			.enterEventPO(potext,testCaseName)
			.confirmCheckout(testCaseName)
			.hitOk()
			.gotoOrderStatus(testCaseName)
			.selectEventPlannerStatus(testCaseName)
			.getZBULOrderdetails(testCaseName, potext);	
	}
	@Test(priority = 3)
	public void windUp()
	{
		quitBrowser(testCaseName);
	}

}
