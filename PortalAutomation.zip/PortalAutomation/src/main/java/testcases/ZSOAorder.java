package testcases;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.QuickEntryPage;

import pages.LoginPage;
import wrappers.PortalWrappers;

public class ZSOAorder extends PortalWrappers {

	@BeforeSuite
	public void snapdirectoryDelete(){
		testCaseName = "ZSOA order";
		try {
			FileUtils.deleteDirectory(new File("E:/work/New folder/PortalAutomation/reports/images/"+testCaseName+"/"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	@BeforeTest
	public void setValues() {
		browserName = "chrome";
		testCaseName = "ZSOA order";
		testDescription = "Create ZSOA order in Portal";
		category="smoke";
		authors="Ram";
//		try {
//			FileUtils.deleteDirectory(new File("E:/work/New folder/PortalAutomation/reports/"+testCaseName+"/"));
//		} catch (IOException e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
	}
	@Test(priority = 0, dataProvider="fetchData")
	public void LogintoPortal(String userID, String passworD, String storeNum) throws IOException{

		invokeApp(browserName,testCaseName );

		new LoginPage(driver, test, testCaseName)

		.EnterUserID(userID, testCaseName)
		.EnterPassword(passworD,testCaseName)
		.ClickLogin(testCaseName)
		.selectStore(testCaseName)
		.selectStoreName(testCaseName)
		.enterStoreNum(storeNum, testCaseName)
		.clickOk(testCaseName)
		.selectQuickEntry(testCaseName);
	}	
	@Test(priority = 1, dataProvider="getArticles")
	public void AddArticles(String rowno, String store, String article, String qty) throws IOException
	{
		new QuickEntryPage(driver, test, testCaseName)

		.enterArticles(rowno, store, article, qty, testCaseName);

	}

	@Test(priority = 2, dataProvider="getPOZSOA")
	public void CheckOut(String potext, String deliverydate) throws IOException, EncryptedDocumentException, InvalidFormatException, InterruptedException
	{
		new QuickEntryPage(driver,test, testCaseName)
			.addtoCart(testCaseName)
			.clickCart()
			.selectLine(testCaseName)
			.clickCheckOut(testCaseName)
			.selectSpecial(testCaseName)
			.clickSubmit(testCaseName)
			.enterRetPO(potext,testCaseName)
			.clickShipRet(testCaseName)
			.clickSpecialCnt(testCaseName)
			.changeSiteDetails(testCaseName)
			.clickRecal(testCaseName)
			.clickCheckOutSpcl(testCaseName)
			.takeSnapOfOrder(testCaseName)
			.gotoOrderStatus(testCaseName)
			.getOrderdetails(testCaseName, potext);	
	}
	@Test(priority = 3)
	public void windUp()
	{
		quitBrowser(testCaseName);
	}
}











