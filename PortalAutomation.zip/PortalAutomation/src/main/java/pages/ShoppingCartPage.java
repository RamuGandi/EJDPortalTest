package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.PortalWrappers;

public class ShoppingCartPage extends PortalWrappers {
	
	public ShoppingCartPage(RemoteWebDriver driver,ExtentTest test){
		this.driver = driver; 
		this.test = test;
	}
	public ShoppingCartPage selectEventPlanner(String testCaseName) throws InterruptedException
	{
		Thread.sleep(5000);
		clickByXpath("//a[contains(text(),'Event Planner') and @class='level1 static highlighted']", testCaseName);
		return this;
	}
	public ShoppingCartPage selectEventLine(String testCaseName) throws InterruptedException
	{
		Thread.sleep(10000);
		clickById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl04_ParentSelectSelectCheckBox", testCaseName);
		return this;
	}
	public ShoppingCartPage selectLine(String testCaseName) throws InterruptedException
	{
		Thread.sleep(5000);
		clickById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl05_CHKCARTSelectCheckBox", testCaseName);
		return this;
	}
	public ShoppingCartPage clickCheckOut(String testCaseName)
	{
		clickById("btnCheckOut", testCaseName);
		return this;
	}
	public ShoppingCartPage selectSpecial(String testCaseName)
	{
		clickByXpath(".//*[@id='rdSpecial']", testCaseName);
		return this;
	}
	
	public ShoppingCartPage clickSubmit(String testCaseName) throws InterruptedException
	{
		clickByXpath(".//*[@id='divConfirmCheckout']/div[2]/input", testCaseName);
		Thread.sleep(10000);
		return this;
	}
	public ShoppingCartPage enterPO(String poText, String testCaseName)
	{
//		String a=".//*[@id='ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl04_TXT_PO Number']";
//		WebDriverWait wt = new WebDriverWait(driver, 5000);
//		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a)));
//		web.sendKeys(poText);
		enterById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl04_TXT_PO Number", poText , testCaseName);
		return this;
	}
	public ShoppingCartPage enterRetPO(String poText, String testCaseName)
	{
		enterById("txtPONumber", poText, testCaseName);
		return this;
	}
	public ShoppingCartPage enterEventPO(String poText, String testCaseName)
	{
		enterById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl05_txtPONumber", poText, testCaseName);
		return this;
	}
	public ShoppingCartPage clickShipRet(String testCaseName)
	{
		clickById("rdImmediateStore", testCaseName);
		return this;
	}
	public ShoppingCartPage clickShipcust(String testCaseName)
	{
		clickById("rdDiffAddress", testCaseName);
		return this;
	}
	public ShoppingCartPage clickSpecialCnt(String testCaseName) throws InterruptedException
	{
		clickById("btnSpcOrderCont", testCaseName);
		Thread.sleep(10000);
		return this;
	}
	
	public ShoppingCartPage enterDlvDate(String dlvdate, String testCaseName)
	{
		enterById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgConfirmationListing_ctl00_ctl04_TXT_EXPECTEDSHIPDATE", dlvdate, testCaseName);
		return this;
	}
	public ShoppingCartPage confirmCheckout(String testCaseName) throws InterruptedException
	{
		clickByXpath(".//*[@id='btnConfirm']", testCaseName);
		Thread.sleep(10000);
		return this;
	}
	public ShoppingCartPage hitOk()
	{
		String a=".//*[@class='PopupOuter ui-draggable']/div[2]/input[1]";
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a)));
		web.click();;
		//clickByXpath(".//*[@class='PopupOuter ui-draggable']/div[2]/input[1]");
		driver.switchTo().defaultContent();
		return this;
	}
	public ShoppingCartPage changeSiteDetails(String testCaseName)
	{
//		WebElement mytable = driver.findElement(By.xpath("(//table[@class='rgMasterTable rgClipCells'])[2]/tbody[1]"));
//		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
//		List<WebElement> Columns_row = rows_table.get(1).findElements(By.tagName("td")); 
//		int rows_count=rows_table.size();
//		int columns_count = Columns_row.size();
//		for(int i=0; i<rows_count; i++){
//			for(int j=0; j<columns_count; j++){
//			WebElement ele = mytable.findElements(By.id("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00__"+i)).get(j);
//			String txt = ele.getAttribute("disabled");
//			System.out.println(txt);	
//			}
//		}
		String qty1= driver.findElement(By.id("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl05_TXT_OH02_QTY")).getAttribute("value");
		String qty2= driver.findElement(By.id("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl07_TXT_AL01_QTY")).getAttribute("value");
		System.out.println(qty1);
		System.out.println(qty2);
		driver.findElement(By.id("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl05_TXT_OH02_QTY")).clear();
		driver.findElement(By.id("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl07_TXT_AL01_QTY")).clear();
		enterById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl05_TXT_AR01_QTY", qty1, testCaseName);
		enterById("ctl00_ctl00_contentMainPlaceHolder_contentMasterCart_rgCartListing_ctl00_ctl07_TXT_AR01_QTY", qty2, testCaseName);
		return this;
	}
	public ShoppingCartPage clickRecal(String testCaseName) throws InterruptedException
	{
		clickById("contentMainPlaceHolder_contentMasterCart_btnRecalculate",testCaseName);
		Thread.sleep(3000);
		return this;
	}
	public ShoppingCartPage clickCheckOutSpcl(String testCaseName)
	{
		clickById("contentMainPlaceHolder_contentMasterCart_btnCheckOut", testCaseName);
		return this;
	}
	public ShoppingCartPage takeSnapOfOrder(String testCaseName)
	{
		verifyTitle("EJD Portal", testCaseName);
		driver.switchTo().defaultContent();
		return this;
	}
	public OrderStatusPage gotoOrderStatus(String testCaseName)
	{
		mouseOverByXpath(".//*[@class='minimenu2']/span[1]", testCaseName);
		clickByXpath(".//*[@class='minimenu2']/ul[1]/li[3]", testCaseName);
		driver.switchTo().frame("iframeAppHost");
		return new OrderStatusPage(driver,test);
	}
}
