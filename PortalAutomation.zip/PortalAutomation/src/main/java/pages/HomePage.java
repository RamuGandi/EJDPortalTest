package pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.PortalWrappers;

public class HomePage extends PortalWrappers{

	public HomePage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver; 
		this.test = test;
	}
	public HomePage selectStore(String testCaseName)
	{
		clickById("awhStoreSelPopup_ddlSearchColumn", testCaseName);
		return this;
	}
	public HomePage selectStoreName(String testCaseName)
	{
		selectIndexByValue("awhStoreSelPopup_ddlSearchColumn", "StoreNo", testCaseName);
		return this;
	}
	public HomePage enterStoreNum(String storeNum, String testCaseName)
	{
		enterById("awhStoreSelPopup_tbxSearchGrid", storeNum, testCaseName);
		return this;
	}
	public HomePage clickOk(String testCaseName)
	{
		clickByClassName("gridHourGlass", testCaseName);
		return this;
	}
	public HomePage clickonsearch(String testCaseName)
	{
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		clickByXpath(".//*[@id='header_ProductSearchBox_solrSearchBox']", testCaseName);
		return this;
	}
	public HomePage enterArticle(String article)
	{
		String c=".//*[@id='header_ProductSearchBox_solrSearchBox']";
		List<WebElement> quickEntry = driver.findElementsByXPath(c);
		int siz=quickEntry.size();
		System.out.println(siz);
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(c)));
		web.sendKeys(article);;
		//enterByID("header_ProductSearchBox_solrSearchBox", article);
		return this;
	}
	public ArticlePage clickSearch()
	{
		String b=".//*[@id='header_ProductSearchBox_hourglass']";
		List<WebElement> quickEntry = driver.findElementsByXPath(b);
		int siz=quickEntry.size();
		System.out.println(siz);
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(b)));
		web.click();
		//clickByXpath(".//*[@id='header_ProductSearchBox_hourglass']");
		return new ArticlePage(driver, test, testCaseName);
	}
	public QuickEntryPage selectQuickEntry(String testCaseName)
	{
		String a="//a[contains(text(),'Quick Entry') and @class='btnHomeLightBlue']";
		List<WebElement> quickEntry = driver.findElementsByXPath(a);
		int siz=quickEntry.size();
		System.out.println(siz);
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a)));
		web.click();
		driver.manage().timeouts().implicitlyWait(8000, TimeUnit.MILLISECONDS);
		driver.switchTo().frame("iframeAppHost");
		//((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)", "");
		//driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		//clickByXpath(a);
		return new QuickEntryPage(driver,test,testCaseName);
		
	}
	public QuickEntryPage selectEventQuckEntry(String testCaseName)
	{
		String a="//a[contains(text(),'Event Quick Entry') and @class='btnHomeDarkBlue']";
		List<WebElement> quickEntry = driver.findElementsByXPath(a);
		int siz=quickEntry.size();
		System.out.println(siz);
		WebDriverWait wt = new WebDriverWait(driver, 5000);
		WebElement web = wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a)));
		web.click();
		driver.manage().timeouts().implicitlyWait(8000, TimeUnit.MILLISECONDS);
		driver.switchTo().frame("iframeAppHost");
		//((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)", "");
		//driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		//clickByXpath(a);
		return new QuickEntryPage(driver,test,testCaseName);

	}
}
