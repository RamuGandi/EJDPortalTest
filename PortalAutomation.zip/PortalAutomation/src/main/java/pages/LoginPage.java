package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.PortalWrappers;

public class LoginPage extends PortalWrappers{
	
	
	public LoginPage(RemoteWebDriver driver,ExtentTest test, String testName){
		this.driver = driver; 
		this.test = test;
		if(!verifyTitle("qaejdportal.com", testName))
			reportStep("This is not Login Page", "FAIL", testName);
	}
		
		public LoginPage EnterUserID(String userID, String testCaseName)
		{
			enterByName("username", userID, testCaseName);
			return this;
		}
		public LoginPage EnterPassword(String passWord, String testCaseName)
		{
			enterByName("password", passWord, testCaseName);
			return this;
		}
		public HomePage ClickLogin(String testCaseName)
		{
			clickByClassName("credentials_input_submit", testCaseName);
			return new HomePage(driver,test);
		}
	}
