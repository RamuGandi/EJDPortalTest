package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.PortalWrappers;

public class ArticlePage extends PortalWrappers{
	
	public ArticlePage(RemoteWebDriver driver, ExtentTest test, String testCaseName)
	{
		this.driver=driver;
		this.test = test;
		if(!verifyTitle("EJD Portal", testCaseName))
			reportStep("This is not Home Page", "FAIL", testCaseName);
	}
	public ArticlePage clickQtyField(String testCaseName)
	{
		clickByClassName("contentMainPlaceHolder_resultListView_tbxQty_0", testCaseName);
		return this;
	}
	public ArticlePage enterQty(String qty, String testCaseName)
	{
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		enterByName("contentMainPlaceHolder_resultListView_tbxQty_0", qty, testCaseName);
		return this;
	}
	
}
