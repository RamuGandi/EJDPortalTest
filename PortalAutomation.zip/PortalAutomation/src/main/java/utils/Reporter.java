package utils;

import java.io.File;
import java.util.Locale;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public abstract class Reporter {
	public ExtentTest test;
	public static ExtentReports extent;
	public String testCaseName, testDescription, category, authors;

	
	public void reportStep(String desc, String status, String testName) {

		long snapNumber = 100000l;
		
		try {
			snapNumber= takeSnap(testName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Write if it is successful or failure or information
		if(status.toUpperCase().equals("PASS")){
			test.log(LogStatus.PASS, desc+test.addScreenCapture("E:/work/New folder/PortalAutomation/reports/images/"+testName+"/"+snapNumber+".jpg"));
		}else if(status.toUpperCase().equals("FAIL")){
			test.log(LogStatus.FAIL, desc+test.addScreenCapture("E:/work/New folder/PortalAutomation/reports/images/"+testName+"/"+snapNumber+".jpg"));
			throw new RuntimeException("FAILED");
		}else if(status.toUpperCase().equals("INFO")){
			test.log(LogStatus.INFO, desc);
		}else if(status.toUpperCase().equals("WARN")){
			test.log(LogStatus.WARNING, desc+test.addScreenCapture("E:/work/New folder/PortalAutomation/reports/images/"+testName+"/"+snapNumber+".jpg"));
		}
	}

	public abstract long takeSnap(String testName);
	

	public ExtentReports startResult(){
		extent = new ExtentReports("E:/work/New folder/PortalAutomation/reports/result.html", true);
		extent.loadConfig(new File("E:/work/New folder/PortalAutomation/resources/extent-config.xml"));
		Locale.setDefault(Locale.ENGLISH);
		return extent;
	}

	public ExtentTest startTestCase(String testCaseName, String testDescription){
		test = extent.startTest(testCaseName, testDescription);
		return test;
	}

	public void endResult(){		
		extent.flush();
	}

	public void endTestcase(){
		extent.endTest(test);
	}

	
	
}
